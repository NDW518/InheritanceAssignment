﻿public abstract class Entertainment
{
    public virtual string title { get; }
    public virtual string platform { get; }
    public virtual string genre { get; }
    public virtual string company { get; }

    public Entertainment(string userTitle, string userPlatform, string userGenre, string userCompany)
    {
        title = userTitle;
        platform = userPlatform;
        genre = userGenre;
        company = userCompany;
    }
}

public class VideoGame : Entertainment
{
/*    protected override string title { get { return ""; } }
    protected override string platform { get { return "";  } }
    protected override string genre { get { return ""; } }
    protected override string company { get { return "";  } }*/

    public string players;
    public string difficulty;

    public VideoGame(string userTitle, string userPlatform, string userGenre, string userCompany, string userPlayers, string userDifficulty) : base(userTitle, userPlatform, userGenre, userCompany)
    {
        players = userPlayers;
        difficulty = userDifficulty;
    }
}

public class TVShow : Entertainment
{
    public string episode_length;
    public int seasons;
    public TVShow(string userTitle, string userPlatform, string userGenre, string userCompany, string userEpisodeLength, int userSeasons) : base(userTitle, userPlatform, userGenre, userCompany)
    {
        episode_length = userEpisodeLength;
        seasons = userSeasons;
    }
}

class Program
{
    static void Main(string[] args)
    {
        VideoGame videoGame1 = new VideoGame("Rainbow Six: Siege", "PS/Xbox/PC", "Action/Strategy", "Ubisoft", "5 vs 5 Multiplayer", "Hard");
        VideoGame videoGame2 = new VideoGame("Horizon Forbidden West", "PS4/5", "Action/Adventure", "Guerrilla Games", "Single Player", "Moderate");

        Console.WriteLine(String.Format("This video game is called {0}. It is a(n) {1} game playable on {2}. It's a(n) {3} {4} game to play and is published by {5}. ", videoGame1.title, videoGame1.genre, videoGame1.platform, videoGame1.difficulty, videoGame1.players, videoGame1.company));
        Console.WriteLine(String.Format("This video game is called {0}. It is a(n) {1} game playable on {2}. It's a(n) {3} {4} game to play and is published by {5}. ", videoGame2.title, videoGame2.genre, videoGame2.platform, videoGame2.difficulty, videoGame2.players, videoGame2.company));

        TVShow TV1 = new TVShow("Regular Show", "HBO Max/Hulu", "Comedy", "Cartoon Network", "10 min", 8);
        TVShow TV2 = new TVShow("Harley Quinn", "HBO Max", "Comic/Comedy", "DC/Warner Bros", "20 min", 2);

        Console.WriteLine(String.Format("{0} is a great {1} show. Produced by {2} and watchable on {3}, it's a very awesome show for when you need a quick laugh, providing you {4} seasons of {5} episodes", TV1.title, TV1.genre, TV1.company, TV1.platform, TV1.seasons, TV1.episode_length));
        Console.WriteLine(String.Format("{0} is a great {1} show. Produced by {2} and watchable on {3}, it's a very awesome show for when you need a quick laugh, providing you {4} seasons of {5} episodes", TV2.title, TV2.genre, TV2.company, TV2.platform, TV2.seasons, TV2.episode_length));
    }
}